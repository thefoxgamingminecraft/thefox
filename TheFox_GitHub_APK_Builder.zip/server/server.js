import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/ask", async (req, res) => {
  try {
    const question = String(req.body?.question ?? "").trim();
    if (!question) return res.status(400).json({error:"question required"});

    const response = await client.responses.create({
      model: "gpt-6-luna",
      instructions: "Tu es The Fox, un assistant vocal français. Réponds clairement, naturellement et de façon concise. Ne prétends pas être humain.",
      input: question
    });

    res.json({ answer: response.output_text });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "AI request failed" });
  }
});

app.listen(3000, "0.0.0.0", () => console.log("The Fox server écoute sur le port 3000"));
