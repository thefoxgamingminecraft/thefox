# Serveur IA The Fox

## 1. Installer Node.js
Puis:
npm install

## 2. Définir la clé API
Ne mets JAMAIS la clé dans l'APK.
Linux/macOS:
export OPENAI_API_KEY="ta_cle"

Windows PowerShell:
$env:OPENAI_API_KEY="ta_cle"

## 3. Lancer
npm start

## 4. Android
Dans FoxService.kt, remplace serverUrl par l'adresse IP de ton serveur, par exemple:
http://192.168.1.20:3000/ask

Le téléphone et le serveur doivent être sur le même réseau si le serveur est chez toi.

Le serveur utilise la Responses API.
