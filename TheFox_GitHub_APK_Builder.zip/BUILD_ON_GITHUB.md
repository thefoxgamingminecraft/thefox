# 🦊 The Fox — compilation depuis un téléphone

Ce projet contient un workflow GitHub Actions qui compile l'APK automatiquement.

## Depuis ton téléphone

1. Crée un dépôt GitHub vide.
2. Envoie tout le contenu de ce dossier dans le dépôt.
3. Ouvre l'onglet **Actions**.
4. Choisis **Build The Fox APK**.
5. Appuie sur **Run workflow**.
6. Quand la compilation est terminée, ouvre l'exécution et télécharge l'artefact **TheFox-debug-apk**.

IMPORTANT:
Le workflow utilise `./gradlew`. Le projet doit donc contenir un Gradle Wrapper complet (`gradlew`, `gradlew.bat` et `gradle/wrapper/gradle-wrapper.jar`).
Si GitHub signale que `gradlew` est absent, il faut générer le wrapper avec Gradle/Android Studio avant de lancer le workflow.

Le serveur IA se trouve dans `server/`. L'APK ne contient volontairement aucune clé API privée.
