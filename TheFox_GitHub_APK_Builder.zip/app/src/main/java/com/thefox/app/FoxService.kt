package com.thefox.app

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.Locale
import org.json.JSONObject

class FoxService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var waitingForQuestion = false
    private val serverUrl = "http://10.0.2.2:3000/ask" // Change this to your server address.

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createChannel()
        startForeground(7, notification())
        listen()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.FRENCH
            tts.setSpeechRate(1.0f)
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale.FRENCH) ?: ""
                if (!waitingForQuestion && text.contains("the fox")) {
                    waitingForQuestion = true
                    speak("Oui, qu'est-ce qu'il y a ?")
                    Handler(Looper.getMainLooper()).postDelayed({ listen() }, 1700)
                } else if (waitingForQuestion && text.isNotBlank()) {
                    waitingForQuestion = false
                    askAI(text)
                } else listen()
            }
            override fun onError(error: Int) { Handler(Looper.getMainLooper()).postDelayed({ listen() }, 400) }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(intent)
    }

    private fun askAI(question: String) {
        Thread {
            try {
                val conn = URL(serverUrl).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.connectTimeout = 10000
                conn.readTimeout = 30000
                conn.doOutput = true
                val body = JSONObject().put("question", question).toString()
                OutputStreamWriter(conn.outputStream).use { it.write(body) }
                val result = conn.inputStream.bufferedReader().readText()
                val answer = JSONObject(result).optString("answer", "Je n'ai pas réussi à répondre.")
                Handler(Looper.getMainLooper()).post {
                    speak(answer)
                    Handler(Looper.getMainLooper()).postDelayed({ listen() }, 2500)
                }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post {
                    speak("Je n'arrive pas à joindre mon intelligence pour le moment.")
                    Handler(Looper.getMainLooper()).postDelayed({ listen() }, 2500)
                }
            }
        }.start()
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "fox")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("fox", "The Fox", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification =
        Notification.Builder(this, "fox")
            .setContentTitle("The Fox")
            .setContentText("En écoute — dis « The Fox »")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}